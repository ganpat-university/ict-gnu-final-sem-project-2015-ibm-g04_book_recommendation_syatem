from pydantic import BaseModel, EmailStr, Field


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class ActivityIn(BaseModel):
    user_id: int
    book_id: int
    event_type: str
    dwell_ms: int = 0


class RecommendOut(BaseModel):
    book_id: int
    score: float
    reason: str
