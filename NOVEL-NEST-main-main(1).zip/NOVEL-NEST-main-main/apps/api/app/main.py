from fastapi import FastAPI

from app.core.database import Base, engine
from app.core.settings import settings
from app.routers import activity, auth, books, recommend, search

app = FastAPI(title=settings.app_name)

Base.metadata.create_all(bind=engine)

app.include_router(auth.router, prefix=settings.api_prefix)
app.include_router(books.router, prefix=settings.api_prefix)
app.include_router(search.router, prefix=settings.api_prefix)
app.include_router(recommend.router, prefix=settings.api_prefix)
app.include_router(activity.router, prefix=settings.api_prefix)


@app.get("/health")
def health():
    return {"ok": True}
