from fastapi import APIRouter, Query

from app.services.recommendation_service import get_recommendation_service

router = APIRouter(tags=["recommendation"])


@router.get("/recommend")
def recommend(user_id: int = Query(..., ge=1), top_k: int = Query(12, ge=1, le=50)):
    svc = get_recommendation_service()
    items = svc.recommend(user_id=user_id, top_k=top_k)
    return {"items": items}
