from fastapi import APIRouter, Query

from app.services.search_service import get_search_service

router = APIRouter(tags=["books"])


@router.get("/books")
def list_books(page: int = Query(1, ge=1), limit: int = Query(20, ge=1, le=100)):
    svc = get_search_service()
    if svc.books_df.empty:
        return {"items": [], "page": page, "limit": limit}
    start = (page - 1) * limit
    end = start + limit
    cols = ["book_id", "title", "author", "avg_rating"]
    cols = [c for c in cols if c in svc.books_df.columns]
    items = svc.books_df.iloc[start:end][cols].to_dict("records")
    return {"items": items, "page": page, "limit": limit}
