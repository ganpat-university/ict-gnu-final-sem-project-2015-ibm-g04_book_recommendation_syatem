from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.schemas import ActivityIn
from app.services.activity_service import log_activity

router = APIRouter(prefix="/user", tags=["activity"])


@router.post("/activity")
def user_activity(payload: ActivityIn, db: Session = Depends(get_db)):
    row = log_activity(db, payload)
    return {"ok": True, "interaction_id": row.id}
