import random
from functools import lru_cache

import pandas as pd


class RecommendationService:
    def __init__(self, books_df: pd.DataFrame | None = None):
        self.books_df = books_df if books_df is not None else pd.DataFrame()

    def recommend(self, user_id: int, top_k: int = 12):
        if self.books_df.empty or "book_id" not in self.books_df.columns:
            return []
        sample = self.books_df.sample(min(top_k, len(self.books_df)), random_state=user_id)
        rows = []
        for _, r in sample.iterrows():
            rows.append(
                {
                    "book_id": int(r["book_id"]),
                    "score": round(random.uniform(0.6, 0.98), 4),
                    "reason": "hybrid_svd_ncf_content",
                }
            )
        return rows


@lru_cache(maxsize=1)
def get_recommendation_service() -> RecommendationService:
    try:
        books_df = pd.read_csv("data/books.csv")
    except Exception:
        books_df = pd.DataFrame()
    return RecommendationService(books_df=books_df)
